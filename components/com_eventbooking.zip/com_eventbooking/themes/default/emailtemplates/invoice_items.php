<?php
/**
 * @package			   Joomla
 * @subpackage		   Event Booking
 * @author			   Tuan Pham Ngoc
 * @copyright		   Copyright (C) 2010 - 2020 Ossolution Team
 * @license			   GNU/GPL, see LICENSE.php
 */

defined('_JEXEC') or die;

$cols = 3;

if ($config->show_event_date)
{
	$itemColumnWidth = '40%';
	$cols++;
}
else
{
	$itemColumnWidth = '60%';
}
?>
<table border="0" width="100%" cellspacing="0" cellpadding="2">
    <thead>
    <tr>
        <th align="left" valign="top" width="10%">#</th>
        <th align="left" valign="top" width="<?php echo $itemColumnWidth; ?>"><?php echo JText::_('EB_ITEM_NAME'); ?></th>
		<?php
		if ($config->show_event_date)
		{
			?>
            <th align="left" valign="top" width="20%"><?php echo JText::_('EB_EVENT_DATE'); ?></th>
			<?php
		}
		?>
        <th align="right" valign="top" width="20%"><?php echo JText::_('EB_PRICE'); ?></th>
        <th align="right" valign="top" width="10%"><?php echo JText::_('EB_SUB_TOTAL'); ?></th>
    </tr>
    </thead>
    <tbody>
	<?php
	$i = 1;
	foreach($rowEvents as $rowEvent)
	{
		?>
        <tr>
            <td>
				<?php echo $i++; ?>
            </td>
            <td>
				<?php echo $rowEvent->title; ?>
            </td>
			<?php
			if ($config->show_event_date)
			{
				?>
                <td align="left">
					<?php
					if ($rowEvent->event_date == EB_TBC_DATE)
					{
						echo JText::_('EB_TBC');
					}
					else
					{
						echo JHtml::_('date', $rowEvent->event_date, $config->event_date_format, null);
					}
					?>
                </td>
				<?php
			}
			?>

            <td align="right">
				<?php echo EventbookingHelper::formatCurrency($rowEvent->total_amount, $config); ?>
            </td>
            <td align="right">
				<?php echo EventbookingHelper::formatCurrency($rowEvent->total_amount, $config); ?>
            </td>
        </tr>
		<?php
	}
	?>
    <tr>
        <td colspan="<?php echo $cols; ?>" align="right" valign="top" width="90%"><?php echo JText::_('EB_AMOUNT'); ?> :</td>
        <td align="right" valign="top" width="10%"><?php echo EventbookingHelper::formatCurrency($subTotal, $config);  ?></td>
    </tr>
    <tr>
        <td colspan="<?php echo $cols; ?>" align="right" valign="top" width="90%"><?php echo JText::_('EB_DISCOUNT_AMOUNT'); ?> :</td>
        <td align="right" valign="top" width="10%"><?php echo EventbookingHelper::formatCurrency($discountAmount, $config); ?></td>
    </tr>
    <tr>
        <td colspan="<?php echo $cols; ?>" align="right" valign="top" width="90%"><?php echo JText::_('EB_TAX');?> :</td>
        <td align="right" valign="top" width="10%"><?php echo EventbookingHelper::formatCurrency($taxAmount, $config); ?></td>
    </tr>
	<?php
	if ($paymentProcessingFee > 0)
	{
		?>
        <tr>
            <td colspan="<?php echo $cols; ?>" align="right" valign="top" width="90%"><?php echo JText::_('EB_PAYMENT_FEE');?> :</td>
            <td align="right" valign="top" width="10%"><?php echo EventbookingHelper::formatCurrency($paymentProcessingFee, $config); ?></td>
        </tr>
		<?php
	}
	?>
    <tr>
        <td colspan="<?php echo $cols; ?>" align="right" valign="top" width="90%"><?php echo JText::_('EB_GROSS_AMOUNT');?></td>
        <td align="right" valign="top" width="10%"><?php echo EventbookingHelper::formatCurrency($total, $config);?></td>
    </tr>
    </tbody>
</table>